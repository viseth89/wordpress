
</div>

</div>
</div>


<footer>
      <p><?php bloginfo('name') ?> &copy; 2019 </p>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>